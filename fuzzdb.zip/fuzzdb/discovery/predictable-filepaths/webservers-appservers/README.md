
Notes:

ADFS.fuzz.txt 
Microsoft ADFS is usually installed on a webserver in under the default HTTP root path location /adfs/ls but this is not mandatory. 

